// Единый источник моковых данных для прототипа «Ноготочки».
const DAY_MS = 24 * 60 * 60 * 1000;
function addDays(d, n) { return new Date(d.getTime() + n * DAY_MS); }
function fmtDate(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
function pad(n) { return String(n).padStart(2, '0'); }

export const salonSettings = {
  address: 'Москва, ул. Цветочная, 12',
  phone: '+7 (999) 123-45-67',
  bookingHorizonMonths: 3,
  minLeadHours: 2,
  freeCancelHours: 24,
  slotHoldMinutes: 10,
  slotStepMinutes: 30,
  workHours: { from: '10:00', to: '20:00' },
  closedWeekdays: [0, 1], // вс, пн (0=вс если считать с вс; используем JS getDay(): 0=вс,1=пн)
};

export const serviceCategories = [
  { id: 'nails', name: 'Маникюр' },
  { id: 'pedicure', name: 'Педикюр' },
  { id: 'extension', name: 'Наращивание' },
  { id: 'brows', name: 'Брови' },
];

export const services = [
  { id: 's1', categoryId: 'nails', name: 'Маникюр с покрытием гель-лаком', desc: 'Классический уход и стойкое покрытие', durationMin: 90, priceFrom: 1800, priceByLevel: { master: 1800, topMaster: 2200 } },
  { id: 's2', categoryId: 'nails', name: 'Маникюр без покрытия', desc: 'Аппаратный или комбинированный уход', durationMin: 45, priceFrom: 1200, priceByLevel: { master: 1200, topMaster: 1500 } },
  { id: 's3', categoryId: 'nails', name: 'Дизайн ногтей', desc: 'Дополнение к маникюру, педикюру или наращиванию', durationMin: 30, priceFrom: 300, priceByLevel: { master: 300, topMaster: 300 }, addon: true },
  { id: 's4', categoryId: 'nails', name: 'Снятие покрытия', desc: 'Аккуратное снятие гель-лака', durationMin: 20, priceFrom: 500, priceByLevel: { master: 500, topMaster: 600 } },
  { id: 's5', categoryId: 'pedicure', name: 'Педикюр с покрытием', desc: 'Уход за стопами и стойкое покрытие', durationMin: 90, priceFrom: 2200, priceByLevel: { master: 2200, topMaster: 2600 } },
  { id: 's6', categoryId: 'pedicure', name: 'Педикюр без покрытия', desc: 'Уход за стопами без покрытия', durationMin: 60, priceFrom: 1600, priceByLevel: { master: 1600, topMaster: 1900 } },
  { id: 's7', categoryId: 'pedicure', name: 'Маникюр и педикюр', desc: 'Комплексный уход за руками и ногами', durationMin: 150, priceFrom: 3200, priceByLevel: { master: 3200, topMaster: 3800 } },
  { id: 's8', categoryId: 'extension', name: 'Наращивание ногтей', desc: 'Форма и длина по вашему желанию', durationMin: 150, priceFrom: 2800, priceByLevel: { master: 2800, topMaster: 3400 } },
  { id: 's9', categoryId: 'extension', name: 'Коррекция наращённых ногтей', desc: 'Поддержание формы между визитами', durationMin: 90, priceFrom: 1800, priceByLevel: { master: 1800, topMaster: 2200 } },
  { id: 's10', categoryId: 'extension', name: 'Снятие наращённых ногтей', desc: 'Бережное снятие материала', durationMin: 30, priceFrom: 600, priceByLevel: { master: 600, topMaster: 700 } },
  { id: 's11', categoryId: 'brows', name: 'Коррекция и окрашивание бровей', desc: 'Форма и цвет, подобранные под лицо', durationMin: 40, priceFrom: 1200, priceByLevel: { master: 1200, topMaster: 1500 } },
  { id: 's12', categoryId: 'brows', name: 'Ламинирование бровей', desc: 'Ухоженный вид без макияжа', durationMin: 60, priceFrom: 1800, priceByLevel: { master: 1800, topMaster: 2100 } },
  { id: 's13', categoryId: 'brows', name: 'Коррекция бровей', desc: 'Только форма, без окрашивания', durationMin: 20, priceFrom: 700, priceByLevel: { master: 700, topMaster: 900 } },
  { id: 's14', categoryId: 'brows', name: 'Окрашивание бровей хной', desc: 'Естественный стойкий цвет', durationMin: 30, priceFrom: 900, priceByLevel: { master: 900, topMaster: 1100 } },
];

export const masters = [
  {
    id: 'm1', name: 'Анна Ковалева', specialty: 'Маникюр и педикюр', level: 'topMaster', rating: 4.9,
    workdays: [2, 3, 4, 5], workHours: { from: '10:00', to: '18:00' }, experienceYears: 7,
    serviceIds: ['s1', 's2', 's3', 's4', 's5', 's6', 's7'],
    reviews: [
      { author: 'Мария К.', text: 'Записалась онлайн вечером, а утром уже знала точное время. Очень удобно.', rating: 5 },
      { author: 'Инна Т.', text: 'Аккуратный маникюр, держится долго.', rating: 5 },
      { author: 'Юлия С.', text: 'Хороший мастер, но иногда есть небольшая задержка по времени.', rating: 4 },
    ],
  },
  {
    id: 'm2', name: 'Марина Орлова', specialty: 'Мастер по бровям', level: 'master', rating: 4.8,
    workdays: [3, 4, 5, 6], workHours: { from: '11:00', to: '20:00' }, experienceYears: 4,
    serviceIds: ['s11', 's12', 's13', 's14'],
    reviews: [
      { author: 'Ольга П.', text: 'Брови сделали именно так, как я хотела показать по фото.', rating: 5 },
      { author: 'Дарья В.', text: 'Внимательный мастер, всё подробно объясняет.', rating: 5 },
      { author: 'Катя М.', text: 'Ламинирование держится почти два месяца.', rating: 5 },
    ],
  },
  {
    id: 'm3', name: 'Елена Смирнова', specialty: 'Универсальный мастер', level: 'master', rating: 4.7,
    workdays: [2, 4, 6], workHours: { from: '10:00', to: '19:00' }, experienceYears: 5,
    serviceIds: ['s1', 's2', 's3', 's5', 's6', 's8', 's9', 's10', 's11', 's13'],
    reviews: [
      { author: 'Света Р.', text: 'Пришла на маникюр и брови в один визит — сэкономила время.', rating: 5 },
      { author: 'Вера Л.', text: 'Хорошо, но запись на удобное время бывает не сразу.', rating: 4 },
      { author: 'Наталья Ф.', text: 'Наращивание держится отлично, без сколов.', rating: 5 },
    ],
  },
  {
    id: 'm4', name: 'Ирина Волкова', specialty: 'Наращивание ногтей', level: 'topMaster', rating: 5.0,
    workdays: [2, 3, 4, 5, 6], workHours: { from: '10:00', to: '20:00' }, experienceYears: 9,
    serviceIds: ['s8', 's9', 's10', 's3'],
    almostFullyBooked: true,
    reviews: [
      { author: 'Алина Ж.', text: 'Лучший мастер по наращиванию в городе, но записаться сложно — очень занята.', rating: 5 },
      { author: 'Полина Г.', text: 'Ждала запись две недели, но результат стоил ожидания.', rating: 5 },
      { author: 'Ксения Д.', text: 'Идеальная форма ногтей каждый раз.', rating: 5 },
    ],
  },
  {
    id: 'm5', name: 'Дарья Соколова', specialty: 'Маникюр и педикюр', level: 'master', rating: 4.6,
    workdays: [2, 3, 4, 5, 6], workHours: { from: '10:00', to: '20:00' }, experienceYears: 3,
    serviceIds: ['s1', 's2', 's4', 's5', 's6', 's7'],
    vacation: { startOffsetDays: 10, lengthDays: 14 },
    reviews: [
      { author: 'Валерия Н.', text: 'Молодой, но старательный мастер.', rating: 4 },
      { author: 'Ирина Б.', text: 'Понравилось покрытие, ровно и аккуратно.', rating: 5 },
      { author: 'Татьяна О.', text: 'Приятная атмосфера во время визита.', rating: 5 },
    ],
  },
];

// Генерация расписания мастера на bookingHorizonMonths вперёд.
export function generateSchedule(masterId) {
  const master = masters.find((m) => m.id === masterId);
  if (!master) return [];
  const today = new Date();
  const days = [];
  const horizonDays = salonSettings.bookingHorizonMonths * 30;
  let vacationStart = null, vacationEnd = null;
  if (master.vacation) {
    vacationStart = addDays(today, master.vacation.startOffsetDays);
    vacationEnd = addDays(vacationStart, master.vacation.lengthDays);
  }
  for (let i = 0; i < horizonDays; i++) {
    const date = addDays(today, i);
    const weekday = date.getDay(); // 0=вс..6=сб
    const salonClosed = salonSettings.closedWeekdays.includes(weekday);
    const masterWorks = master.workdays.includes(weekday);
    const onVacation = vacationStart && date >= vacationStart && date < vacationEnd;
    let status = 'available';
    if (salonClosed) status = 'salonClosed';
    else if (onVacation) status = 'vacation';
    else if (!masterWorks) status = 'masterOff';
    const busy = [];
    if (status === 'available') {
      const stepMin = salonSettings.slotStepMinutes;
      const [fh, fm] = master.workHours.from.split(':').map(Number);
      const [th, tm] = master.workHours.to.split(':').map(Number);
      const startMin = fh * 60 + fm, endMin = th * 60 + tm;
      const slotsCount = (endMin - startMin) / stepMin;
      // детерминированная "занятость" — псевдослучайно по дню/индексу
      const fillRatio = master.almostFullyBooked ? 0.97 : 0.35;
      for (let s = 0; s < slotsCount; s++) {
        const seed = (i * 7 + s * 13 + masterId.length) % 100;
        if (seed / 100 < fillRatio) {
          const mins = startMin + s * stepMin;
          busy.push(`${pad(Math.floor(mins / 60))}:${pad(mins % 60)}`);
        }
      }
    }
    days.push({ date: fmtDate(date), weekday, status, busy });
  }
  return days;
}

// Отпуск мастера относительно текущей даты.
export function getVacationInfo(master, ref = new Date()) {
  if (!master.vacation) return null;
  const start = addDays(ref, master.vacation.startOffsetDays);
  const end = addDays(start, master.vacation.lengthDays);
  return { start, end, active: ref >= start && ref < end };
}

// Ближайший свободный слот мастера с учётом минимального времени до записи.
export function nearestFreeSlot(masterId) {
  const master = masters.find((m) => m.id === masterId);
  if (!master) return null;
  const schedule = generateSchedule(masterId);
  const now = new Date();
  const minLeadMs = salonSettings.minLeadHours * 3600 * 1000;
  const [fh, fm] = master.workHours.from.split(':').map(Number);
  const [th, tm] = master.workHours.to.split(':').map(Number);
  const startMin = fh * 60 + fm, endMin = th * 60 + tm;
  const step = salonSettings.slotStepMinutes;
  for (const day of schedule) {
    if (day.status !== 'available') continue;
    for (let mins = startMin; mins < endMin; mins += step) {
      const time = `${pad(Math.floor(mins / 60))}:${pad(mins % 60)}`;
      if (day.busy.includes(time)) continue;
      const dt = new Date(day.date + 'T' + time + ':00');
      if (dt.getTime() - now.getTime() < minLeadMs) continue;
      return { date: day.date, time };
    }
  }
  return null;
}

// Несовместимые в одном визите услуги (мок для проверки конфликтов).
export const incompatiblePairs = [
  { pair: ['s1', 's8'], reason: 'Маникюр с покрытием и наращивание ногтей выполняются на одних и тех же ногтях — выберите одну из услуг.' },
];

export function findIncompatible(cartIds, newId) {
  for (const item of incompatiblePairs) {
    const [a, b] = item.pair;
    if ((newId === a && cartIds.includes(b)) || (newId === b && cartIds.includes(a))) return item;
  }
  return null;
}

// Тестовый клиент и его записи.
export const testClient = { id: 'c1', name: 'Мария Кузнецова', phone: '+7 (911) 222-33-44', email: 'maria@example.com' };

export const testClientBookings = (() => {
  const now = new Date();
  const inHours = (h) => new Date(now.getTime() + h * 3600 * 1000);
  const agoDays = (d) => addDays(now, -d);
  return [
    { id: 'b1', serviceId: 's1', status: 'active', service: 'Маникюр с покрытием гель-лаком', master: 'Анна Ковалева', masterId: 'm1', datetime: inHours(30), durationMin: 90, price: '1 800 ₽', canModify: true, comment: 'Пожалуйста, покороче форму', address: salonSettings.address },
    { id: 'b2', serviceId: 's11', status: 'active', service: 'Коррекция и окрашивание бровей', master: 'Марина Орлова', masterId: 'm2', datetime: inHours(10), durationMin: 40, price: '1 200 ₽', canModify: false, restrictReason: 'Изменение недоступно менее чем за сутки до визита', address: salonSettings.address },
    { id: 'b8', serviceId: 's8', status: 'pending', service: 'Наращивание ногтей', master: 'Ирина Волкова', masterId: 'm4', datetime: inHours(96), durationMin: 150, price: '2 800 ₽', canModify: true, address: salonSettings.address },
    { id: 'b3', serviceId: 's7', status: 'done', service: 'Маникюр и педикюр', master: 'Елена Смирнова', masterId: 'm3', datetime: agoDays(6), durationMin: 150, price: '3 200 ₽', address: salonSettings.address },
    { id: 'b4', serviceId: 's8', status: 'done', service: 'Наращивание ногтей', master: 'Ирина Волкова', masterId: 'm4', datetime: agoDays(20), durationMin: 150, price: '2 800 ₽', address: salonSettings.address },
    { id: 'b5', serviceId: 's12', status: 'done', service: 'Ламинирование бровей', master: 'Марина Орлова', masterId: 'm2', datetime: agoDays(45), durationMin: 60, price: '1 800 ₽', address: salonSettings.address },
    { id: 'b6', serviceId: 's2', status: 'cancelledClient', service: 'Маникюр без покрытия', master: 'Дарья Соколова', masterId: 'm5', datetime: agoDays(12), durationMin: 45, price: '1 200 ₽', address: salonSettings.address },
    { id: 'b7', serviceId: 's5', status: 'cancelledStudio', service: 'Педикюр с покрытием', master: 'Анна Ковалева', masterId: 'm1', datetime: agoDays(30), durationMin: 90, price: '2 200 ₽', reason: 'Мастер заболела', address: salonSettings.address },
    { id: 'b9', serviceId: 's13', status: 'noShow', service: 'Коррекция бровей', master: 'Марина Орлова', masterId: 'm2', datetime: agoDays(50), durationMin: 20, price: '700 ₽', address: salonSettings.address },
  ];
})();


// ---- Помощники для шага «Дата и время» ----

export function findCoveringMasters(cartIds) {
  return masters.filter((m) => cartIds.every((id) => m.serviceIds.includes(id)));
}

function getMasterDay(masterId, dateStr) {
  return generateSchedule(masterId).find((d) => d.date === dateStr);
}

// Список окон {start,end}, куда целиком помещается визит длительностью durationMin.
export function getFreeStartTimes(masterId, dateStr, durationMin) {
  const day = getMasterDay(masterId, dateStr);
  if (!day || day.status !== 'available') return [];
  const master = masters.find((m) => m.id === masterId);
  const [fh, fm] = master.workHours.from.split(':').map(Number);
  const [th, tm] = master.workHours.to.split(':').map(Number);
  const startMin = fh * 60 + fm, endMin = th * 60 + tm;
  const step = salonSettings.slotStepMinutes;
  const busySet = new Set(day.busy);
  const now = new Date();
  const isToday = dateStr === fmtDate(now);
  const minLeadMs = salonSettings.minLeadHours * 3600 * 1000;
  const results = [];
  for (let mins = startMin; mins + durationMin <= endMin; mins += step) {
    let ok = true;
    for (let m = mins; m < mins + durationMin; m += step) {
      const t = pad(Math.floor(m / 60)) + ':' + pad(m % 60);
      if (busySet.has(t)) { ok = false; break; }
    }
    if (!ok) continue;
    const startTime = pad(Math.floor(mins / 60)) + ':' + pad(mins % 60);
    if (isToday) {
      const dt = new Date(dateStr + 'T' + startTime + ':00');
      if (dt.getTime() - now.getTime() < minLeadMs) continue;
    }
    const endMins = mins + durationMin;
    const endTime = pad(Math.floor(endMins / 60)) + ':' + pad(endMins % 60);
    results.push({ start: startTime, end: endTime });
  }
  return results;
}

export function dayHasAvailability(masterIds, dateStr, durationMin) {
  return masterIds.some((id) => getFreeStartTimes(id, dateStr, durationMin).length > 0);
}

// Следующие count дат (после fromDateStr), где у кого-то из masterIds есть окно.
export function nextAvailableDates(masterIds, durationMin, fromDateStr, count = 3) {
  if (!masterIds.length) return [];
  const schedule = generateSchedule(masterIds[0]);
  const out = [];
  for (const day of schedule) {
    if (day.date <= fromDateStr) continue;
    if (dayHasAvailability(masterIds, day.date, durationMin)) {
      out.push(day.date);
      if (out.length >= count) break;
    }
  }
  return out;
}

// Первый доступный слот в горизонте записи (для «Ближайшее свободное время»).
export function nearestAvailableSlot(masterIds, durationMin) {
  if (!masterIds.length) return null;
  const schedule = generateSchedule(masterIds[0]);
  for (const day of schedule) {
    for (const masterId of masterIds) {
      const slots = getFreeStartTimes(masterId, day.date, durationMin);
      if (slots.length) return { date: day.date, start: slots[0].start, end: slots[0].end, masterId };
    }
  }
  return null;
}

// Есть ли хоть один слот во всём горизонте (для «всё занято» / «нет окна для визита»).
export function hasAnyAvailability(masterIds, durationMin) {
  return !!nearestAvailableSlot(masterIds, durationMin);
}


function nextAvailableDatesDetailed(masterIds, durationMin, fromDateStr, count) {
  const schedule = generateSchedule(masterIds[0]);
  const out = [];
  for (const day of schedule) {
    if (day.date <= fromDateStr) continue;
    for (const id of masterIds) {
      const slots = getFreeStartTimes(id, day.date, durationMin);
      if (slots.length) { out.push({ date: day.date, start: slots[0].start, end: slots[0].end, masterId: id }); break; }
    }
    if (out.length >= count) break;
  }
  return out;
}

// Альтернативные слоты при конфликте (сначала тот же день, затем следующие дни).
export function getAlternativeSlots(masterIds, dateStr, durationMin, excludeStart, count = 5) {
  const sameDay = [];
  masterIds.forEach((id) => {
    getFreeStartTimes(id, dateStr, durationMin).forEach((s) => {
      if (s.start !== excludeStart) sameDay.push({ date: dateStr, start: s.start, end: s.end, masterId: id });
    });
  });
  let out = sameDay.slice(0, count);
  if (out.length < count) out = out.concat(nextAvailableDatesDetailed(masterIds, durationMin, dateStr, count - out.length));
  return out.slice(0, count);
}
